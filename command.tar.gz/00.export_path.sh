WorkingDir=/lustre/home/kimzz14/archive/SRA_MAPPING/IRGSP-1.0/01.GATK-4.1.6.0-thlee00/01.variant_call

##################################################################################
CurrentDir=$(readlink -f .)
if [ $CurrentDir = $WorkingDir ]
then
	echo "Same"

	#bwa-0.7.17
	export PATH=$WorkingDir/src_packages/bwa-0.7.17:$PATH

	#samtools-1.9
	export PATH=$WorkingDir/src_packages/samtools-1.10/bin:$PATH

	#jre1.8.0_241
	export PATH=$WorkingDir/src_packages/jre1.8.0_241/bin:$PATH

	#gatk-4.1.6.0
	export PATH=$WorkingDir/src_packages/gatk-4.1.6.0:$PATH
else
	echo "Diff"
fi

##################################################################################
