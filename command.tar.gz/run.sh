#sh step01_GATK-CombineGVCF.sh
#sh step02_GATK-GenotypeGVCFs.sh
sh step03_GATK-SplitVCF.sh
sh run2.sh &
sh run3.sh &
