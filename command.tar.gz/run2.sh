sh step04_GATK-VariantFiltration-SNP.sh
sh step06_GATK-SelectVariants-SNP.sh
sh step08_GATK-VariantsToTable-SNP.sh
