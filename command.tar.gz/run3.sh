sh step05_GATK-VariantFiltration-InDel.sh
sh step07_GATK-SelectVariants-InDel.sh
sh step09_GATK-VariantsToTable-InDel.sh
