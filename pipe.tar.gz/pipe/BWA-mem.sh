read_dir=/lustre/home/kimzz14/archive/SRA_RAW/Trimmomatic/result
tmp_dir=/dev/shm/kimzz14/SRA_MAPPING/tmp

mkdir $tmp_dir/$1

rsync -a $read_dir/$1.rm_adapter.trim.1.fastq.gz $tmp_dir/$1/.
rsync -a $read_dir/$1.rm_adapter.trim.2.fastq.gz $tmp_dir/$1/.

bwa mem -t $2 reference/ref.fa \
$tmp_dir/$1/$1.rm_adapter.trim.1.fastq.gz \
$tmp_dir/$1/$1.rm_adapter.trim.2.fastq.gz \
1> $tmp_dir/$1/$1.aln-pe.sam \
2> $tmp_dir/$1/$1.aln-pe.sam.log 

samtools flagstat $tmp_dir/$1/$1.aln-pe.sam \
1> $tmp_dir/$1/$1.aln-pe.sam.flagstat \
2> $tmp_dir/$1/$1.aln-pe.sam.flagstat.log

rm $tmp_dir/$1/$1.rm_adapter.trim.1.fastq.gz
rm $tmp_dir/$1/$1.rm_adapter.trim.2.fastq.gz

for i in 1 2
do
    rsync -a $read_dir/$1.rm_adapter.trim.unpaired_${i}.fastq.gz $tmp_dir/$1/.

    bwa mem -t $2 reference/ref.fa \
    $tmp_dir/$1/$1.rm_adapter.trim.unpaired_${i}.fastq.gz \
    1> $tmp_dir/$1/$1.aln-se.${i}.sam \
    2> $tmp_dir/$1/$1.aln-se.${i}.sam.log 
    rm $tmp_dir/$1/$1.rm_adapter.trim.unpaired_${i}.fastq.gz
    
    samtools flagstat $tmp_dir/$1/$1.aln-se.${i}.sam \
    1> $tmp_dir/$1/$1.aln-se.${i}.sam.flagstat \
    2> $tmp_dir/$1/$1.aln-se.${i}.sam.flagstat.log

done

gatk --java-options "-Djava.io.tmpdir=$tmp_dir/$1/tmp" MergeSamFiles \
--INPUT=$tmp_dir/$1/$1.aln-pe.sam \
--INPUT=$tmp_dir/$1/$1.aln-se.1.sam \
--INPUT=$tmp_dir/$1/$1.aln-se.2.sam \
--SORT_ORDER=coordinate \
--OUTPUT=$tmp_dir/$1/$1.bam \
1> $tmp_dir/$1/$1.bam.log \
2> $tmp_dir/$1/$1.bam.err

samtools flagstat $tmp_dir/$1/$1.bam \
1> $tmp_dir/$1/$1.bam.flagstat \
2> $tmp_dir/$1/$1.bam.flagstat.log


rm $tmp_dir/$1/$1.aln-pe.sam
rm $tmp_dir/$1/$1.aln-se.1.sam
rm $tmp_dir/$1/$1.aln-se.2.sam
