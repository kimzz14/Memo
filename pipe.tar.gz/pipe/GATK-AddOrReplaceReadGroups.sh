read_dir=/lustre/home/kimzz14/archive/SRA_RAW/all
tmp_dir=/dev/shm/kimzz14/SRA_MAPPING/tmp

gatk --java-options "-Djava.io.tmpdir=$tmp_dir/$1/tmp" AddOrReplaceReadGroups \
--INPUT=$tmp_dir/$1/$1.bam \
--OUTPUT=$tmp_dir/$1/$1.RGsorted.bam \
--SORT_ORDER=coordinate \
--MAX_RECORDS_IN_RAM=1280000 \
--VALIDATION_STRINGENCY=LENIENT \
--RGID=$1 \
--RGLB=$1_LIB \
--RGPL=ILLUMINA \
--RGPU=NONE \
--RGSM=$1 \
1> $tmp_dir/$1/$1.RGsorted.bam.log \
2> $tmp_dir/$1/$1.RGsorted.bam.err \
&& samtools index \
$tmp_dir/$1/$1.RGsorted.bam \
1> $tmp_dir/$1/$1.RGsorted.bam.bai.log \
2> $tmp_dir/$1/$1.RGsorted.bam.bai.err

rm $tmp_dir/$1/$1.bam
