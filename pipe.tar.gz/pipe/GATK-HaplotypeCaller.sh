read_dir=/lustre/home/kimzz14/archive/SRA_RAW/all
tmp_dir=/dev/shm/kimzz14/SRA_MAPPING/tmp

gatk --java-options "-Djava.io.tmpdir=$tmp_dir/$1/tmp" HaplotypeCaller \
-ERC GVCF \
--reference reference/ref.fa \
--input  $tmp_dir/$1/$1.RGsorted.dedupped.bam \
--output $tmp_dir/$1/$1.RGsorted.dedupped.HaplotypeCaller.g.vcf.gz \
1>       $tmp_dir/$1/$1.RGsorted.dedupped.HaplotypeCaller.g.vcf.gz.log \
2>       $tmp_dir/$1/$1.RGsorted.dedupped.HaplotypeCaller.g.vcf.gz.err
