read_dir=/lustre/home/kimzz14/archive/SRA_RAW/all
tmp_dir=/dev/shm/kimzz14/SRA_MAPPING/tmp

gatk --java-options "-Djava.io.tmpdir=$tmp_dir/$1/tmp" MarkDuplicates \
--INPUT=$tmp_dir/$1/$1.RGsorted.bam \
--OUTPUT=$tmp_dir/$1/$1.RGsorted.dedupped.bam \
--METRICS_FILE=$tmp_dir/$1/$1.RGsorted.dedupped.metrics \
--REMOVE_DUPLICATES=true \
--ASSUME_SORTED=true \
--MAX_RECORDS_IN_RAM=1280000 \
--VALIDATION_STRINGENCY=LENIENT \
--MAX_FILE_HANDLES=1024 \
1> $tmp_dir/$1/$1.RGsorted.dedupped.bam.log \
2> $tmp_dir/$1/$1.RGsorted.dedupped.bam.err \
&& samtools index \
$tmp_dir/$1/$1.RGsorted.dedupped.bam \
1> $tmp_dir/$1/$1.RGsorted.dedupped.bam.bai.log \
2> $tmp_dir/$1/$1.RGsorted.dedupped.bam.bai.err

rm $tmp_dir/$1/$1.RGsorted.bam
