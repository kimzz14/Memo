read_dir=/lustre/home/kimzz14/archive/SRA_RAW/all
tmp_dir=/dev/shm/kimzz14/SRA_MAPPING/tmp

samtools flagstat \
--threads $2 \
$tmp_dir/$1/$1.RGsorted.bam \
1> $tmp_dir/$1/$1.RGsorted.bam.flagstat \
2> $tmp_dir/$1/$1.RGsorted.bam.flagstat.log
