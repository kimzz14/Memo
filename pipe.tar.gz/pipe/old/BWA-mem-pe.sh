read_dir=/lustre/home/kimzz14/archive/SRA_RAW/Trimmomatic/result
tmp_dir=/dev/shm/kimzz14/SRA_MAPPING/tmp

rsync -a $read_dir/$1.rm_adapter.trim.1.fastq.gz $tmp_dir/.
rsync -a $read_dir/$1.rm_adapter.trim.2.fastq.gz $tmp_dir/.

./src_packages/bwa-0.7.17/bwa \
mem \
-t $2 \
reference/ref.fa \
$tmp_dir/$1.rm_adapter.trim.1.fastq.gz \
$tmp_dir/$1.rm_adapter.trim.2.fastq.gz \
2> $tmp_dir/$1.aln-pe.sam.gz.log \
| gzip 1> $tmp_dir/$1.aln-pe.sam.gz 2> $tmp_dir/$1.aln-pe.sam.gz.gzip_log

rm $tmp_dir/$1.rm_adapter.trim.1.fastq.gz
rm $tmp_dir/$1.rm_adapter.trim.2.fastq.gz
