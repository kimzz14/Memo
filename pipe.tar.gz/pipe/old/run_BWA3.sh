read_dir=/lustre/home/kimzz14/archive/SRA_RAW/Trimmomatic/result
tmp_dir=/dev/shm/kimzz14/SRA_MAPPING/tmp

mkdir $tmp_dir/$1

rsync -a $read_dir/$1.rm_adapter.trim.1.fastq.gz $tmp_dir/$1/.
rsync -a $read_dir/$1.rm_adapter.trim.2.fastq.gz $tmp_dir/$1/.

bwa mem -t $2 reference/ref.fa \
$tmp_dir/$1/$1.rm_adapter.trim.1.fastq.gz \
$tmp_dir/$1/$1.rm_adapter.trim.2.fastq.gz \
1> $tmp_dir/$1/$1.aln-pe.sam \
2> $tmp_dir/$1/$1.aln-pe.sam.log 

#rm $tmp_dir/$1/$1.rm_adapter.trim.1.fastq.gz
#rm $tmp_dir/$1/$1.rm_adapter.trim.2.fastq.gz

samtools view -S $tmp_dir/$1/$1.aln-pe.sam -b -o $tmp_dir/$1/$1.aln-pe.bam 1> $tmp_dir/$1/$1.aln-pe.bam.log 2> $tmp_dir/$1/$1.aln-pe.bam.err
#rm $tmp_dir/$1/$1.aln-pe.sam

samtools sort --threads $2 $tmp_dir/$1/$1.aln-pe.bam -o $tmp_dir/$1/$1.aln-pe.sort.bam 1> $tmp_dir/$1/$1.aln-pe.sort.bam.log 2> $tmp_dir/$1/$1.aln-pe.sort.bam.err
#rm $tmp_dir/$1/$1.aln-pe.bam

samtools index $tmp_dir/$1/$1.aln-pe.sort.bam 1> $tmp_dir/$1/$1.aln-pe.sort.bam.bai.log 2> $tmp_dir/$1/$1.aln-pe.sort.bam.bai.err


for i in 1 2
do
    rsync -a $read_dir/$1.rm_adapter.trim.unpaired_${i}.fastq.gz $tmp_dir/$1/.

    bwa mem -t $2 reference/ref.fa \
    $tmp_dir/$1/$1.rm_adapter.trim.unpaired_${i}.fastq.gz \
    1> $tmp_dir/$1/$1.aln-se.${i}.sam \
    2> $tmp_dir/$1/$1.sln-se.${i}.sam.log \
    #rm $tmp_dir/$1/$1.rm_adapter.trim.unpaired_${i}.fastq.gz

    samtools view -S $tmp_dir/$1/$1.aln-se.${i}.sam -b -o $tmp_dir/$1/$1.aln-se.${i}.bam 1> $tmp_dir/$1/$1.aln-se.${i}.bam.log 2> $tmp_dir/$1/$1.aln-se.${i}.bam.err
    #rm $tmp_dir/$1/$1.aln-se.${i}.sam

    samtools sort --threads $2 $tmp_dir/$1/$1.aln-se.${i}.bam -o $tmp_dir/$1/$1.aln-se.${i}.sort.bam 1> $tmp_dir/$1/$1.aln-se.${i}.sort.bam.log 2> $tmp_dir/$1/$1.aln-se.${i}.sort.err
    #rm $tmp_dir/$1/$1.aln-se.${i}.bam
    samtools index $tmp_dir/$1/$1.aln-se.${i}.sort.bam 1> $tmp_dir/$1/$1.aln-se.${i}.sort.bam.bai.log 2> $tmp_dir/$1/$1.aln-se.${i}.sort.bam.bai.err
done

samtools merge $tmp_dir/$1/$1.unsort.bam $tmp_dir/$1/$1.aln-pe.sort.bam $tmp_dir/$1/$1.aln-se.1.sort.bam $tmp_dir/$1/$1.aln-se.2.sort.bam 1> $tmp_dir/$1/$1.unsort.bam.log 2> $tmp_dir/$1/$1.unsort.bam.err
samtools sort --threads $2 $tmp_dir/$1/$1.unsort.bam -o $tmp_dir/$1/$1.bam 1> $tmp_dir/$1/$1.bam.log 2> $tmp_dir/$1/$1.bam.err
samtools index $tmp_dir/$1/$1.bam 1> $tmp_dir/$1/$1.bam.bai.log 2> $tmp_dir/$1/$1.bam.bai.err
