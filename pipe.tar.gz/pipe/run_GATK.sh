read_dir=/lustre/home/kimzz14/archive/SRA_RAW/Trimmomatic/result
tmp_dir=/dev/shm/kimzz14/SRA_MAPPING/tmp

sh pipe/BWA-mem.sh $1 $2
sh pipe/GATK-AddOrReplaceReadGroups.sh $1
sh pipe/GATK-MarkDuplicates.sh $1
sh pipe/GATK-HaplotypeCaller.sh $1

mv $tmp_dir/$1/* result/.

echo $1 done!
