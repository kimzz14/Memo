read_dir=/lustre/home/kimzz14/archive/SRA_RAW/Trimmomatic/result
tmp_dir=/dev/shm/kimzz14/SRA_MAPPING/tmp

for i in 1 2
do
    bwa mem -t $2 reference/ref.fa \
    $tmp_dir/$1/$1.rm_adapter.trim.unpaired_${i}.fastq.gz \
    1> $tmp_dir/$1/$1.aln-se.${i}.sam \
    2> $tmp_dir/$1/$1.aln-se.${i}.sam.log
done
